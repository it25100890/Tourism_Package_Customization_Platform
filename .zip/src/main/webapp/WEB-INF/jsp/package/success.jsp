
<h2>Booking Successful ! </h2>

<p>Your package booking has been confirmed.</p>

<a href="/packages">Back to Packages</a>
