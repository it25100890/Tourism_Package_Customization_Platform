<%@ page import="java.util.*, com.tourism.platform.model.TourismPackage" %>

<h2 style = "text-align:center;color:#1f3a5f;">Tourism Packages</h2>

<div style="width:80%; margin:auto;">

<table border="1" cellpadding="10"
style="width:100%;
       border-collapse: collapse;
       text-align:center";>

<tr style = "background-color:#5dade2;
color:white;">
    <th>ID</th>
    <th>Name</th>
    <th>Description</th>
    <th>Location</th>
    <th>Price</th>
    <th>Days</th>
    <th>Action</th>
</tr>

<%
List<TourismPackage> list = (List<TourismPackage>) request.getAttribute("packages");

if(list != null){
    for(TourismPackage p : list){
%>

<tr style="background-color:#eaf2f8;">
    <td><%=p.getPackageId()%></td>
    <td><%=p.getPackageName()%></td>
    <td style="text-align:left;"><%=p.getDescription()%></td>
    <td><%=p.getLocation()%></td>
    <td><%=p.getPrice()%></td>
    <td><%=p.getDuration()%></td>

    <%-- Book button: sends package ID to booking form --%>
    <td>
        <a href="/add?id=<%=p.getPackageId()%>"
        style="padding:6px 10px;
        background-color:#3498db;
        color:white; text-decoration:none;">Book
        </a>
    </td>
</tr>

<%
    }
}
%>

</table>

</div>




