
<h2>Booking Confirmation</h2>

<h3>Total Price: <%= request.getAttribute("price") %></h3>

<p>Do you accept the package?</p>

<form action="/accept" method="post">
    <button type="submit">Yes</button>
</form>

<form action="/reject" method="post">
    <button type="submit">No</button>
</form>
