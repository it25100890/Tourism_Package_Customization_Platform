
<h2>Booking Cancelled !</h2>

<p>You have rejected the package.</p>

<a href="/add">Try Again</a>
