
<style>
input {
    background-color: white !important;
}

input:-webkit-autofill {
    background-color: white !important;
    -webkit-box-shadow: 0 0 0px 1000px white inset !important;
}
</style>

<h2 style="text-align:center;color:#1f3a5f">Book Package</h2>

<div style="width:40%;
margin:auto;
padding:20px;
border:1px solid #ccc;
border-radius:8px;
background-color:#eaf4ff;">

<form action="/bookPackage" method="post">

   <label> Customer Name: </label><br>
   <input type="text" name="customerName"
        style="width:100%; padding:8px;background-color:#ffffff;border:1px solid #999;border-radius:4px;"><br><br>

   <label> Email:</label><br>
   <input type="text" name="email"
        style="width:100%; padding:8px;background-color:#ffffff;border:1px solid #999;border-radius:4px;"><br><br>

    <label> Contact Number: </label><br>
    <input type="text" name="contact"
        style="width:100%; padding:8px;background-color:#ffffff;border:1px solid #999;border-radius:4px;"><br><br>

    <%-- package ID comes from URL.User cannot change it. --%>

    <label> Package ID: </label><br>
    <input type="text" name="id" value="${id}" readonly
         style="width:100%; padding:8px;background-color:#ffffff;border:1px solid #999;border-radius:4px;"><br><br>

    <label> Number of Travellers: </label><br>
    <input type="text" name="travellers"
         style="width:100%; padding:8px;background-color:#ffffff;border:1px solid #999;border-radius:4px;"><br><br>

    <button type="submit"
         style="width:100%; padding:10px;
                   background-color:#1f3a5f;
                   color:white;
                   border:none;
                   border-radius:5px;"
    >Submit</button>
   </form>
</div>