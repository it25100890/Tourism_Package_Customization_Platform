package com.tourism.platform.controller;

import com.tourism.platform.repository.PackageRepository;
import com.tourism.platform.model.TourismPackage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.util.List;

@Controller
public class PackageController {
    private PackageRepository repository = new PackageRepository();

    @GetMapping("/packages")
    public String viewPackages(Model model) throws IOException {
        List<TourismPackage> list = repository.getAllPackages();
        model.addAttribute("packages", list);

        return "package/view-packages";
    }

    @PostMapping("/bookPackage")
    public String addPackage(

            @RequestParam String id,
            @RequestParam String customerName,
            @RequestParam String email,
            @RequestParam String contact,
            @RequestParam (defaultValue = "1") int travellers,
            Model model
    ) throws IOException {

// Example price calculation (fixed for now)
        double pricePerPerson = 10000;
        double totalPrice = travellers * pricePerPerson;


// SAVE booking
        repository.saveBooking(id, customerName, email, contact, travellers);


        model.addAttribute("price", totalPrice);

        return "package/confirmation";
    }

    @PostMapping("/accept")
    public String accept() {
        return "package/success";
    }

    @PostMapping("/reject")
    public String reject() {
        return "package/reject";
    }

    @GetMapping("/add")
    public String showAddPage(@RequestParam(required = false) String id, Model model) {
        model.addAttribute("id", id);
        return "package/book-package";
    }
}