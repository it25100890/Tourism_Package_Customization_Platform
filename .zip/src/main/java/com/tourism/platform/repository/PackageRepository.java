package com.tourism.platform.repository;
import com.tourism.platform.model.TourismPackage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PackageRepository {

    private static final String FILE_PATH = "src/main/resources/data/packages.txt";

    public List<TourismPackage> getAllPackages() throws IOException {
        List<TourismPackage> packageList = new ArrayList<>();


        BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH));
        String line;

        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");

            TourismPackage pkg = new TourismPackage(
                    data[0],
                    data[1],
                    data[2],
                    data[3],
                    Double.parseDouble(data[4]),
                    Integer.parseInt(data[5]),
                    Boolean.parseBoolean(data[6])
            );
            packageList.add(pkg);
        }
        reader.close();
        return packageList;
    }

    public void addPackage(TourismPackage pkg) throws IOException {

        BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true));

        writer.write(pkg.getPackageId() + "," +
                pkg.getPackageName() + "," +
                pkg.getDescription()+ "," +
                pkg.getLocation() + "," +
                pkg.getPrice() + "," +
                pkg.getDuration() + "'" +
                true);

        writer.newLine();
        writer.close();
    }

    public void saveBooking(String id,String name,String email,String contact,int travellers)throws IOException {

        BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH.replace("package.txt", "booking.txt"), true));

        writer.write(id + "," + name + " ," + email + " ," + contact + " ," + travellers);
        writer.newLine();

        writer.close();

    }
}
